package com.fiqri.moviemania.model

data class OrderMovie (
    val movie: Movie,
    val count: Int
)